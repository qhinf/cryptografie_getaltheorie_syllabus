import random
from functies import *
from rsa import Rsa
from diffie_hellman import *


# Dit is de main functie, hier hoeft niets te gebeuren
# Kijk wel goed naar hoe de code in elkaar zit, dan weet je wat de functie moet doen.
def main():
    a, m = 91, 14   # a en m kunnen elke waarde aannemen in ℕ
    ggd, x, priem_a = 7, 1, False
    _ggd, _x, _y = ggd_uitgebreid(a, m)

    assert priem(a) == priem_a, "Fout in functie priem"                 # deel 1a
    assert ggd_euclides(a, m) == ggd, "Fout in functie ggd_euclides"    # deel 1b
    assert modulo(a, m) == a % m, "Fout in functie modulo"              # deel 2a
    assert _ggd == ggd and _x == x, "Fout in functie ggd_uitgebreid"    # deel 2b

    # controleer of de diffie_hellman functies werken
    g = genereer_priemgetal(30)     # de publieke restklasse
    p = genereer_priemgetal(30)     # alles in modulo p
    a = genereer_priemgetal(30)     # de privé sleutel van Alice
    b = genereer_priemgetal(30)     # de privé sleutel van Bob

    A = prive_sleutel(a, g, p)      # Alice berekend haar 'tussensleutel'
    B = prive_sleutel(b, g, p)      # Bob berekend zijn 'tussensleutel'

    sleutel_alice = gemeenschappelijke_sleutel(B, a, p)   # Alice berekend de geheime sleutel
    sleutel_bob   = gemeenschappelijke_sleutel(A, b, p)   # Bob berekend de geheime sleutel
    assert sleutel_alice == sleutel_bob, "Foute diffie_hellman sleutel"

    # Test de de class rsa
    p, q = genereer_priemgetal(30), genereer_priemgetal(30)
    test_rsa: Rsa = Rsa(p, q)

    bericht = "Cryptografie en getaltheorie"
    versleuteld = test_rsa.versleutel(bericht)
    ontsleuteld = test_rsa.ontsleutel(versleuteld)
    assert bericht == ontsleuteld, "Foute ontsleuteling"    # deel 3

    # controleer of de rsa class goed werkt
    print("Bericht    :", bericht)
    print("ontsleuteld:", ontsleuteld)
    print("versleuteld:", versleuteld)


def genereer_priemgetal(lengte):
    getal = random.randint(2 ** (lengte - 1), 2 ** lengte)
    while not priem(getal):
        getal = random.randint(2 ** (lengte - 1), 2 ** lengte)
    return getal


if __name__ == '__main__':
    main()

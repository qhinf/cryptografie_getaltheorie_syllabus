# Opdracht 1a
# Geeft aan of het getal een priemgetal is
def priem(getal):
    isPriem = True
    return isPriem


# Opdracht 1b
# Het standard algoritme van euclides
def ggd_euclides(a, m):
    ggd = 1
    return ggd


# Opdracht 2a
# Modulo op je eigen manier
def modulo(a, m):
    modulo = 1
    return modulo



# Opdracht 2b
# Het uitgebreide algoritme van euclides
def ggd_uitgebreid(a, m):
    ggd = 1
    b = 1
    k = 1
    return ggd, b, k

from functies import *
import random


# Opdracht 3
# class Rsa die gebruikt maakt van de functies 'priem' en 'ggd_uitgebreid'
class Rsa:

    def __init__(self, p, q):
        self.m = 1
        self.__phi = 1
        self.e = 1
        self.__d = 1

    def bereken_e(self):
        return 1


    def bereken_d(self):
        return 1


    def versleutel(self, message):
        return [1]


    def ontsleutel(self, ciphertext):
        return "Nog niet geimplementeerd!"



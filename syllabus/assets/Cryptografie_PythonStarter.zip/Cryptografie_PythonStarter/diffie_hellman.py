def prive_sleutel(a, g, p):
    return 100


def gemeenschappelijke_sleutel(g_a, b, p):
    return 200
